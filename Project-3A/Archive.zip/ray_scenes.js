// routines for creating a ray tracing scene
class Light {
  //let lights = [];
  constructor(x, y, z, r, g, b) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.r = r;
    this.g = g;
    this.b = b;
  }
    addLight(r, g, b, x, y, z) {
    light = [r, g, b, x, y, z];
    lights.push(light);
  }
  
}

class Scene {
  constructor(bgR, bgG, bgB, ang) {
    this.bgR = 0;
    this.bgG = 0;
    this.bgB = 0;
  }
  set brR(r) {
    this.bgR = r;
  }
  get brR() {
    return this.bgR;
  }
  set brG(g) {
    this.bgG = r;
  }
  get brG() {
    return this.bgG;
  }
  set brB(b) {
    this.bgB = b;
  }
  get brB() {
    return this.bgB;
  }
  set ang(a) {
    this.fovAng = a;
  } 
  get ang() {
    return this.fovAng;
  }  
}

class Ray {
  constructor(orig, dir) {
    this.orig = orig;
    this.dir = dir;
  }
  get direction() {
    return this.dir;
  }
  set direction(dir) {
    this.dir = dir;
}
  get orig() {
    return this.orig;
  }
  set orig(orig) {
    this.orig = orig;
  }
}
class Surface {
  constructor(dR, dG, dB) {
    this.dR = dR;
    this.dG = dG;
    this.dB = dB;
  }
  set dR(num) {
    this.dR = num;
  }
  get dR() {
    return this.dR;
  }
  
  set dG(num) {
    this.dG = num;
  }
  get dG() {
    return this.dG;
  }
  set dB(num) {
    this.dB = num;
  }
  get dB() {
    return this.dB;
  }
}

class Sphere {
  constructor(x, y, z, radius, surface) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.radius = radius;
    this.surface = surface;
  }
  get x() {
    return this.x;
  }
  set x(num) {
    this.x = num;
  }
  get y() {
    return this.y;
  }
  set y(num) {
    this.y = num;
  }
  get z() {
    return this.z;
  }
  set z(num) {
    this.z = num;
  }
  get radius() {
    return this.radius;
  }
  set radius(rad) {
    this.radius = rad;
  }
  get surface() {
    return this.surface;
  }
  set surface(surf) {
    this.surface = surf;
  }
}
class Hit {
  constructor(t, pos, obj) {
    this.t = t;
    this.pos = pos;
    this.obj = obj;
  }
  get t() {
    return this.t;
  }
  set t(num) {
  this.t = num;
}
  get pos() {
    return this.pos;
  }
  
  set pos(num) {
    this.pos = num;
  }
  get obj() {
    return this.obj;
  }
  set obj(object) {
    this.obj = object;
  }
}
let red = 0.0;
let green = 0.0;
let blue = 0.0;

let aRed = 0.0;
let aGreen = 0.0;
let aBlue = 0.0;

let eyeX = 0.0;
let eyeY = 0.0;
let eyeZ = 0.0;

let fov = 0.0;

let uX = 0.0;
let uY = 0.0;
let uZ = 0.0;
let vX = 0.0;
let vY = 0.0;
let vZ = 0.0;
let wX = 0.0;
let wY = 0.0;
let wZ = 0.0;
 
//let bg = Background(0, 0, 0);
let lights = [];
let shapes = [];
//let colors = new Colors(0, 0, 0);
//let surfaces = [];




//let scn = Scene(background, lights, shapes, k);
// clear out all scene contents
function reset_scene() {
    let red = 0.0;
    let green = 0.0;
    let blue = 0.0;

    let eyeX = 0.0;
    let eyeY = 0.0;
    let eyeZ = 0.0;

    let fov = 0.0;

    let uX = 0.0;
    let uY = 0.0;
    let uZ = 0.0;
    let vX = 0.0;
    let vY = 0.0;
    let vZ = 0.0;
    let wX = 0.0;
    let wY = 0.0;
    let wZ = 0.0;
    
    let bg = new PVector(0, 0, 0);
    let lights = [];
    let shapes = [];
    let surfaces = [];
    let colors = new Colors(0, 0, 0);
}



// create a new point light source
function new_light (r, g, b, x, y, z) {
    let light = [r, g, b, x, y, z];
    lights.push(light);
}

// set value of ambient light source
function ambient_light (r, g, b) {
    let aRed = r;
    let aGreen = g;
    let aBlue = b;
}

// set the background color for the scene
function set_background (r, g, b) {
    red = r;
    green = g;
    blue = b;
  
}

// set the field of view
function set_fov (theta) {
  fov = theta;
}

// set the position of the virtual camera/eye
function set_eye_position (x, y, z) {
    let eyeX = x;
    let eyeY = y;
    let eyeZ = z;
}

// set the virtual camera's viewing direction
function set_uvw(x1,y1, z1, x2, y2, z2, x3, y3, z3) {
    let uX = x1;
    let uY = y1;
    let uZ = z1;
    let vX = x2;
    let vY = y2;
    let vZ = z2;
    let wX = x3;
    let wY = y3;
    let wZ = z3;
}

// create a new sphere
function new_sphere (x, y, z, radius, dr, dg, db, k_ambient, k_specular, specular_pow) {
    let r = radius;
    let sX = x;
    let sY = y;
    let sZ = z;
    let surf = new Surface(dr, dg, db);
    let sphere = new Sphere(sX, sY, sZ, r, surf);
    let colors = new Color(dr, dg, db);
    shapes.push(sphere);
}

// create an eye ray based on the current pixel's position
function eye_ray_uvw (i, j) {
}
function intersect(ray, object) {
  
    let dX = ray.dir.x;
    let dY = ray.dir.y;
    let dZ = ray.dir.z;
    let x1 = ray.orig.x;
    let y1 = ray.orig.y;
    let z1 = ray.orig.z;
    
    if (typeof(object) == Sphere) {
        x2 = object.x;
        y2 = object.y;
        z2 = object.z;
        radius = object.radius;
        
        a = ((dX * dX) + (dY * dY) + (dZ * dZ));
        b = (2 * ((dX * (x1 - x2)) + (dY * (y1 - y2)) + (dZ * (z1 - z2))));
        c = ((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) + (z1 - z2) * (z1 - z1) - (radius * radius));
        d = (b * b) - (4 * a * c);

        //let roots = [];
        
        if (d < 0) {
            return null;
        } else {
            let t = (-b - sqrt(( b *b ) - (4 * a * c))) / (2 * a);
            let intX = ray.orig.x + (t * dX);
            let intY = ray.orig.y + (t * dY);
            let intZ = ray.orig.z + (t * dZ);
        
        inter = PVector(intX, intY, intZ);
        
        hitO = Hit(t, inter, s);
        return hitO;
      } 
   }
}
// this is the main routine for drawing your ray traced scene
function draw_scene() {

  noStroke();  // so we don't get a border when we draw a tiny rectangle

  // go through all the pixels in the image
  
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      //let theta = 2 * PI * scene;
      let u = -1 + (2 * x/float(width));
      let v = -(-1 + (2 * y/float(height)));
      let d = 1.0/tan(radians(fov)/2.0);
      let orig = PVector(0, 0, 0);
      let eyeRayDir = PVector(u, v, -1);
      eyeRayDir = eyeRayDir.normalize();
      let ray = Ray(orig, eyeRayDir);
      let high = 9999;
      let last = null;
      let hit = [];
      for (let i = 0; i <= shapes.length(); i++) {
          let object = shapes[i];
          //let ray = Ray(Vertex(0, 0, 0), Vertex(xP, yP, zP));
          hit.push(intersect(ray, object));
      }
      
      for (let i = 0; i <= hit.length(); i++) {
        let hi = hit[i];
        if (hi != null) {
          if (hi.t < high && hi.t >= 0) {
            last = hit[i];
          }
       }
    }
    
    let pixCol = PVector(0, 0, 0);
    if (last != null) {
      let col = PVector(last.obj.surface.dR, last.obj.surface.dG, last.obj.surface.dB);
      pixCol = col;
      N = PVector((last.pos.x - last.obj.x) / last.obj.radius, (last.pos.y - last.obj.y) / last.obj.radius, (last.pos.z - last.obj.z) / last.obj.radius);
      let light = 0;
      let lVec = PVector(0.0, 0.0, 0.0);
      for (i = 0; i < lights.length(); i++) {
        let l = lights[i];
        let lPos = PVector(l[3], l[4], l[5]);
        let lvec = (lPos - last.pos).normalize();
        let lCol = PVector(l[0], l[1], l[2]);
        lvecC = lCol * max(0, N.dot(lvec));
        lvecC1 = lvecC1 + lvecC;
        
      }
      pixCol = PVector(col.x * lvecC1.x, col.y * lvecC1.y, col.z * lvecC1);
    } else {
      let scene = new Scene();
      pixCol = PVector(scene.bgR, scene.bgG, scene.bgB);
    }
    let pix_color = color(picCOl.x, pixCol.y, pixCol.z);
    set (i, j, pix_color);
      
      // create eye ray
      //let ray = eye_ray_uvw (x, y);
      
      // maybe print debug information
      debug_flag = 0;
      //if (x == width / 2 && y == height / 2) { debug_flag = 1;  }  // un-comment to debug center pixel
      
      if (debug_flag) {
        console.log ("debug at: " + x + " " + y);
      }
      
      // Figure out the pixel's color here (FOR YOU TO WRITE!!!)
      
      let r,g,b;  // placeholders to store the pixel's color

      // set the pixel color, converting values from [0,1] into [0,255]
      fill (255 * r, 255 * g, 255 * b);
      
      rect (x, y, 1, 1);   // make a little rectangle to fill in the pixel
    }
  }
  
}
